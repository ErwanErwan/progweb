function fromVille() {
    const ville = document.getElementById("ville").value;
    getFromApi(ville);
}

async function getFromApi(input) {
    const url = 'https://www.prevision-meteo.ch/services/json/' + input;
    const response = fetch(url);
    response.then((response) => {
        const data = response.json();
        data.then((data) => {
            printInfo(data);
        });
    });
}

function printInfo(data) {
    console.log(data);

    document.getElementById("data").innerHTML = `
            <pre>${JSON.stringify(data.city_info, null, 2)}</pre>
        `;
}
const xx = 48.0;
const yy = 2.4;
var map = L.map('map').setView([xx, yy], 10);

L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

function PingMap(x, y) {
    L.marker([x, y]).addTo(map)
        .bindPopup('Latitude : ' + x + '<br>Longitude : ' + y)
        .openPopup();
}

L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(map);

var popup = L.popup();

function onMapClick(e) {
    popup
        .setLatLng(e.latlng)
        .setContent("You clicked the map at " + e.latlng.toString())
        .openOn(map);
    PingMap(e.latlng.lat, e.latlng.lng);
    getNameFromApi(e.latlng.lat, e.latlng.lng);
    getFromApi('lat=' + e.latlng.lat + 'lng=' + e.latlng.lng);
}

function getNameFromApi(lat, lng) {
    const url = 'https://nominatim.openstreetmap.org/reverse?lat=' + lat + '&lon=' + lng + '&format=json';
    const response = fetch(url);
    response.then((response) => {
        const data = response.json();
        data.then((data) => {
            const name = data.address.town || data.address.village || data.address.city || data.address.county || data.address.state || data.address.country;
            console.log(name);
            document.getElementById("name").innerHTML = name;
        });
    });
}

map.on('click', onMapClick);